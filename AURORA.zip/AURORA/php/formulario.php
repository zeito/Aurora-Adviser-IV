<?php

$name = $_POST['name'];
$email = $_POST['email'];

$formcontent="
    Nombre: $name \n
    E-mail: $email
";

$recipient = "palvarezarrano@gmail.com";

$subject = "auroraaa";

$header = "From: $email \r\n";
$header .= "Content-Type: text/plain; charset=UTF-8";
mail($recipient, $subject, $formcontent, $header) or die("Error!");
header("Location: inicio.html");

?>